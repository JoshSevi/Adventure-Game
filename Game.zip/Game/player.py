class Player:
    def __init__(self):
        self.name = ''
        self.memories = ''
        self.age = ''
        self.origin = ''


player1 = Player()